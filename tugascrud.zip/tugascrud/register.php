<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<form action="login.php" method="post">
<body>
  <style>
    body {
      background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTt4bRbhH0nsle-kvQ9kfbV1J7muqXJ_QYoCg&usqp=CAU');
      background-repeat: no-repeat;
      background-size: 100%;
    }

    button {
      background-color: gray;
    }
  </style>
<center>
<h1>Halaman Register</h1>

<div class="input-group input-group-lg">    
  <span class="input-group-text" id="basic-addon1">@</span>
  <input type="text" class="form-control" placeholder="Nama" aria-label="Nama" aria-describedby="basic-addon1" name ="nama_minuman">
</div>
<br>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">#</span>
  <input type="text" class="form-control" placeholder="Rasa" aria-label="Rasa" aria-describedby="basic-addon1" name= "rasa_minuman">
</div>
<br>

<button type="submit">Sign-In</button>
</form>
</center>
</div>
</div>
</body>

</html>
