<?php
  $servername = "localhost:3306";
  $username_db = "root";
  $password_db = "";
  $database_name = "tugascrud";

  $namaminuman = $_POST['nama_minuman'];
  $rasaminuman = $_POST['rasa_minuman'];

  $conn = new mysqli($servername, $username_db, $password_db, $database_name);

  if($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
  } else {
    $stmt = $conn->prepare("insert into admin(nama_minuman, rasa_minuman) values(?, ?)");
    $stmt->bind_param("ss", $namaminuman, $rasaminuman,);
    $stmt->execute();
  header(location:login.php);
    } 
  ?>