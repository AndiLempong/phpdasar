<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>

    <style>
    body {
      background-image: url('https://e0.pxfuel.com/wallpapers/386/919/desktop-wallpaper-website-background-website-login-page-background.jpg');
      background-repeat: no-repeat;
      background-size: 100%;
    }

    button {
        background-color: gray;
    }
  </style>
</head>
<form action="connect_login.php" method="post">
<body>
<center>
    <h1>Halaman Login</h1>

    <form action="" method="post">

        <div class="input-group flex-nowrap">
  <span class="input-group-text" id="addon-wrapping">@</span>
  <input type="text" class="form-control" placeholder="Email" aria-label="Email" aria-describedby="addon-wrapping" name="email">
</div>
<br>

<div class="input-group flex-nowrap">
  <span class="input-group-text" id="addon-wrapping">$</span>
  <input type="text" class="form-control" placeholder="Password" aria-label="Password" aria-describedby="addon-wrapping" name="password">
  <br>
  <br>
  <button>Sign In</button>
    </form>
</div>
</center>
</body>
</html>