<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<form action="connect_regrister.php" method="post">
<body>
  <style>
    body {
      background-image: url('https://img.freepik.com/free-photo/blue-office-stationery-set-with-laptop_23-2147843325.jpg');
      background-repeat: no-repeat;
      background-size: 100%;
    }

    button {
      background-color: gray;
    }
  </style>
<center>
<h1>Halaman Register</h1>

<div class="input-group input-group-lg">    
  <span class="input-group-text" id="basic-addon1">@</span>
  <input type="text" class="form-control" placeholder="Email" aria-label="Email" aria-describedby="basic-addon1">
</div>
<br>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">#</span>
  <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1">
</div>
<br>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">?</span>
  <input type="text" class="form-control" placeholder="Password" aria-label="Password" aria-describedby="basic-addon1">
</div>
<br>
<button>Sign-In</button>
</form>
</center>
</div>
</div>
</body>

</html>
